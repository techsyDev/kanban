import React from "react";
import "./index.css";
import KanbanBoard from "./KanbanBoard";


export default function KanbanPage() {
  return (
    <>
  
    <div className="w-full mt-10">
      <KanbanBoard  />
    </div>
  </>
  )
}


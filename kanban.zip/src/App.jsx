
import Kanban from './kanban'
import KanbanPage from "./KanbanBoard/KanbanPage"

function App() {


  return (
    <Kanban/>
    // <KanbanPage/>
  )
}

export default App
